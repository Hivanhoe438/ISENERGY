package com.example.myfirstapp;

public class PeriodGraph {

    public static PeriodDate[] getPeriod()  {
        PeriodDate date1 = new PeriodDate("jour");
        PeriodDate date2 = new PeriodDate("mois");
        PeriodDate date3 = new PeriodDate("année");

        return new PeriodDate[] {date1, date2, date3};
    }
}
