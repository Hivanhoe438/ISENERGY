package com.example.isenergyv1;

public class PeriodDate {

    private String date;


    public PeriodDate(String date) {
        this.date = date;
    }



    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }




    /*public String getFullName()  {
        return this.firstName + " " + this.lastName;
    }

    // Text show in Spinner
    @Override
    public String toString()  {
        return this.getFullName() + " - (" + this.position+")";
    }*/
    @Override
    public String toString()  {
        return this.date;
    }
}
