package com.example.isenergyv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivityGraph extends AppCompatActivity {

    private Button returnMenu;
    private Spinner spinnerDate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_graph);

        this.spinnerDate = (Spinner) findViewById(R.id.spinner_Date);

        PeriodDate[] periodDate = PeriodGraph.getPeriod();

        // (@resource) android.R.layout.simple_spinner_item:
        //   The resource ID for a layout file containing a TextView to use when instantiating views.
        //    (Layout for one ROW of Spinner)
        ArrayAdapter<PeriodDate> adapter = new ArrayAdapter<PeriodDate>(this,
                android.R.layout.simple_spinner_item,
                periodDate);

        // Layout for All ROWs of Spinner.  (Optional for ArrayAdapter).
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        this.spinnerDate.setAdapter(adapter);

        // When user select a List-Item.
        this.spinnerDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                onItemSelectedHandler(parent, view, position, id);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        this.returnMenu=(Button) findViewById(R.id.returnMenu);

        returnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });
    }

    private void onItemSelectedHandler(AdapterView<?> adapterView, View view, int position, long id) {
        Adapter adapter = adapterView.getAdapter();
        PeriodDate periodDate = (PeriodDate) adapter.getItem(position);

        Toast.makeText(getApplicationContext(), "Selected PeriodDate: " + periodDate.getDate() ,Toast.LENGTH_SHORT).show();
    }

}